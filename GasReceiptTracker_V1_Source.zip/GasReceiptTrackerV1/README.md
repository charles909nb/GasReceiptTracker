# Gas Receipt Tracker V1.0 — Android starter project

This is a **source-code test build**, not an installable APK. Open the project in Android Studio and build an APK (Build > Build APK(s)). Gradle and the Android SDK are not available in the current build environment, so this code has not been compiled or device-tested.

## Implemented in this starter
- Per-phone driver profile, stored locally.
- New receipt draft created immediately.
- Autosave of editable station, vehicle, odometer, gallons, total and notes to SQLite after changes.
- Photo capture via system camera; stores full-resolution JPEG in app-private storage and associates it with receipt draft.
- GPS capture via Android LocationManager with user permission; saves latitude/longitude and accuracy if available.
- Signature pad; saved as PNG independently of reimbursement completion.
- List of drafts and receipts; resume existing draft; status "Ready" when a signature, photo, odometer, and vehicle exist.

## Still planned (not implemented)
- OCR receipt recognition and verification; vehicle directory; export/import, backup/restore; duplicate warnings; reimbursement template output; encryption beyond Android's app sandbox.

## Important
- All changes are persisted promptly, but data entered during an abrupt power loss before the final SQLite transaction may be lost.
- Android may clear app data on uninstall; do not rely on this prototype as the sole archive of reimbursement documents.
- Do not use real sensitive receipts until a tested release and backup/export are available.
