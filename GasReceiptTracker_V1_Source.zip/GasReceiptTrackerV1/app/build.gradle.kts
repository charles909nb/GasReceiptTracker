plugins { id("com.android.application") }
android { namespace = "org.example.gasreceipt"; compileSdk = 35
 defaultConfig { applicationId = "org.example.gasreceipt"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0-test" } }
